import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QDialog, QLineEdit, QHBoxLayout
from PyQt5.QtCore import Qt
from datetime import datetime, timedelta

class Book:
    def __init__(self, title, author, genre, status="dostępna", borrower=None, borrow_date=None):
        self.title = title
        self.author = author
        self.genre = genre
        self.status = status
        self.borrower = borrower
        self.borrow_date = borrow_date if borrow_date else datetime.now()

    def is_overdue(self):
        """Sprawdza, czy książka jest przeterminowana"""
        if self.status == "wypożyczona":
            return datetime.now() > self.borrow_date + timedelta(days=14)
        return False

    def borrow(self, borrower_name):
        """Wypożyczenie książki"""
        self.status = "wypożyczona"
        self.borrower = borrower_name
        self.borrow_date = datetime.now()
        
    def return_book(self):
        """Zwrócenie książki"""
        self.status = "dostępna"
        self.borrower = None
        self.borrow_date = None

class LibraryApp(QWidget):
    def __init__(self):
        super().__init__()

        # Lista książek
        self.books = [
            Book("W pustyni i w puszczy", "Henryk Sienkiewicz", "Przygodowa"),
            Book("Pan Tadeusz", "Adam Mickiewicz", "Epopeja"),
            Book("Quo Vadis", "Henryk Sienkiewicz", "Historyczna", "wypożyczona", "Jan Kowalski", datetime.now() - timedelta(days=5)),
            Book("Lalka", "Bolesław Prus", "Powieść"),
            Book("Harry Potter", "J.K. Rowling", "Fantasy", "wypożyczona", "Anna Nowak", datetime.now() - timedelta(days=15)),
        ]

        # GUI
        self.setWindowTitle("Biblioteka")
        self.setGeometry(100, 100, 800, 600)
        self.layout = QVBoxLayout()

        self.table = QTableWidget(self)
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Tytuł", "Autor", "Gatunek", "Status", "Data wypożyczenia"])
        self.layout.addWidget(self.table)

        self.update_table()

        self.sort_button = QPushButton("Sortuj po tytule", self)
        self.sort_button.clicked.connect(self.sort_books)
        self.layout.addWidget(self.sort_button)

        self.filter_button = QPushButton("Filtruj wypożyczone", self)
        self.filter_button.clicked.connect(self.filter_borrowed)
        self.layout.addWidget(self.filter_button)

        self.setLayout(self.layout)

    def update_table(self):
        """Aktualizacja tabeli z książkami"""
        self.table.setRowCount(len(self.books))
        for row, book in enumerate(self.books):
            self.table.setItem(row, 0, QTableWidgetItem(book.title))
            self.table.setItem(row, 1, QTableWidgetItem(book.author))
            self.table.setItem(row, 2, QTableWidgetItem(book.genre))
            status_item = QTableWidgetItem(book.status)
            if book.is_overdue():
                status_item.setBackground(Qt.red)
            self.table.setItem(row, 3, status_item)
            self.table.setItem(row, 4, QTableWidgetItem(str(book.borrow_date.date()) if book.borrow_date else ""))

    def sort_books(self):
        """Sortowanie książek po tytule"""
        self.books.sort(key=lambda x: x.title)
        self.update_table()

    def filter_borrowed(self):
        """Filtracja książek wypożyczonych"""
        self.books = [book for book in self.books if book.status == "wypożyczona"]
        self.update_table()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LibraryApp()
    window.show()
    sys.exit(app.exec_())
