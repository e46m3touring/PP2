from datetime import datetime, timedelta

class Book:
    def __init__(self, title, author, genre, status="dostępna", borrower=None, borrow_date=None):
        self.title = title
        self.author = author
        self.genre = genre
        self.status = status
        self.borrower = borrower
        self.borrow_date = borrow_date if borrow_date else datetime.now()

    def is_overdue(self):
        """Sprawdza, czy książka jest przeterminowana"""
        if self.status == "wypożyczona":
            return datetime.now() > self.borrow_date + timedelta(days=14)
        return False

    def borrow(self, borrower_name):
        """Wypożyczenie książki"""
        self.status = "wypożyczona"
        self.borrower = borrower_name
        self.borrow_date = datetime.now()
        
    def return_book(self):
        """Zwrócenie książki"""
        self.status = "dostępna"
        self.borrower = None
        self.borrow_date = None
